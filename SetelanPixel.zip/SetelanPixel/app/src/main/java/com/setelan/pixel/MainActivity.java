package com.setelan.pixel;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.location.*;
import android.net.*;
import android.net.wifi.*;
import android.os.*;
import android.provider.Settings;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.webkit.*;
import android.widget.EditText;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    WebView web;
    WifiManager wm;
    BluetoothAdapter ba;
    LocationManager lm;
    WifiManager.LocalOnlyHotspotReservation hs;
    String hsS = "", hsP = "";
    Handler ui = new Handler(Looper.getMainLooper());

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        ba = BluetoothAdapter.getDefaultAdapter();
        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
        perm();
        IntentFilter f = new IntentFilter();
        f.addAction(BluetoothDevice.ACTION_FOUND);
        f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        f.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        f.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        registerReceiver(rc, f);
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(rc); lm.removeUpdates(ll); if (hs != null) hs.close(); } catch (Exception e) {}
        super.onDestroy();
    }

    void perm() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
    }

    void emit(String ev, String json) {
        final String js = "window.__n&&window.__n('" + ev + "'," + json + ")";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    void msg(String m) {
        try { emit("msg", new JSONObject().put("msg", m).toString()); } catch (Exception e) {}
    }

    void locErr(String m) {
        try { emit("locerr", new JSONObject().put("msg", m).toString()); } catch (Exception e) {}
    }

    void pushScan() {
        try {
            JSONArray a = new JSONArray();
            Set<String> seen = new HashSet<>();
            List<ScanResult> l = new ArrayList<>(wm.getScanResults());
            Collections.sort(l, (x, y) -> y.level - x.level);
            for (ScanResult r : l) {
                if (r.SSID == null || r.SSID.isEmpty() || !seen.add(r.SSID)) continue;
                String c = r.capabilities;
                JSONObject o = new JSONObject();
                o.put("ssid", r.SSID);
                o.put("sec", c.contains("WEP") || c.contains("PSK") || c.contains("EAP") || c.contains("SAE"));
                o.put("lv", WifiManager.calculateSignalLevel(r.level, 100));
                a.put(o);
            }
            emit("wifiscan", a.toString());
        } catch (Exception e) {}
    }

    void pushBonded() {
        try {
            JSONArray a = new JSONArray();
            if (ba != null) for (BluetoothDevice d : ba.getBondedDevices()) {
                JSONObject o = new JSONObject();
                o.put("name", d.getName() == null ? d.getAddress() : d.getName());
                o.put("addr", d.getAddress());
                a.put(o);
            }
            emit("bonded", a.toString());
        } catch (Exception e) {}
    }

    void pushLoc(Location l) {
        try {
            JSONObject o = new JSONObject();
            o.put("lat", l.getLatitude());
            o.put("lon", l.getLongitude());
            o.put("acc", l.getAccuracy());
            o.put("alt", l.hasAltitude() ? l.getAltitude() : JSONObject.NULL);
            o.put("spd", l.hasSpeed() ? l.getSpeed() : 0);
            o.put("t", l.getTime());
            emit("loc", o.toString());
        } catch (Exception e) {}
    }

    void join(String ssid, String pass) {
        try {
            WifiConfiguration c = new WifiConfiguration();
            c.SSID = "\"" + ssid + "\"";
            if (pass == null) c.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
            else c.preSharedKey = "\"" + pass + "\"";
            int id = wm.addNetwork(c);
            if (id < 0) { msg("Gagal menambah jaringan (mungkin sudah tersimpan oleh sistem)"); return; }
            wm.disconnect();
            boolean ok = wm.enableNetwork(id, true);
            wm.reconnect();
            msg(ok ? "Menyambungkan ke " + ssid + "..." : "Gagal menyambung");
        } catch (Exception e) { msg("Gagal: " + e.getMessage()); }
    }

    LocationListener ll = new LocationListener() {
        @Override public void onLocationChanged(Location l) { pushLoc(l); }
        @Override public void onStatusChanged(String p, int s, Bundle e) {}
        @Override public void onProviderEnabled(String p) {}
        @Override public void onProviderDisabled(String p) {}
    };

    BroadcastReceiver rc = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            try {
                if (BluetoothDevice.ACTION_FOUND.equals(a)) {
                    BluetoothDevice d = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    if (d.getBondState() == BluetoothDevice.BOND_BONDED) return;
                    JSONObject o = new JSONObject();
                    o.put("name", d.getName() == null ? "" : d.getName());
                    o.put("addr", d.getAddress());
                    emit("btfound", o.toString());
                } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(a)) {
                    emit("btdone", "{}");
                } else if (BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(a)) {
                    pushBonded();
                    emit("bond", "{}");
                } else if (WifiManager.SCAN_RESULTS_AVAILABLE_ACTION.equals(a)) {
                    pushScan();
                }
            } catch (Exception e) {}
        }
    };

    class Bridge {
        @JavascriptInterface public String info() {
            try {
                JSONObject o = new JSONObject();
                String nm = Settings.Global.getString(getContentResolver(), "device_name");
                o.put("name", nm == null ? "" : nm);
                o.put("brand", Build.MANUFACTURER);
                o.put("model", Build.MODEL);
                o.put("android", Build.VERSION.RELEASE);
                o.put("sdk", Build.VERSION.SDK_INT);
                o.put("patch", Build.VERSION.SDK_INT >= 23 ? Build.VERSION.SECURITY_PATCH : "");
                o.put("build", Build.DISPLAY);
                o.put("kernel", System.getProperty("os.version"));
                o.put("cores", Runtime.getRuntime().availableProcessors());
                o.put("abi", Build.SUPPORTED_ABIS[0]);
                o.put("hw", Build.HARDWARE);
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                ((ActivityManager) getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi);
                o.put("ram", mi.totalMem / 1048576);
                StatFs sf = new StatFs(Environment.getDataDirectory().getPath());
                o.put("st", sf.getTotalBytes() / 1e9);
                o.put("sf", sf.getAvailableBytes() / 1e9);
                DisplayMetrics dm = getResources().getDisplayMetrics();
                o.put("scr", dm.widthPixels + " x " + dm.heightPixels + " px - " + dm.densityDpi + " dpi");
                Intent bi = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                int sc = bi.getIntExtra("scale", 100);
                int stt = bi.getIntExtra("status", 0);
                o.put("bl", bi.getIntExtra("level", 0) * 100 / (sc == 0 ? 100 : sc));
                o.put("chg", stt == BatteryManager.BATTERY_STATUS_CHARGING || stt == BatteryManager.BATTERY_STATUS_FULL);
                o.put("wifiOn", wm.isWifiEnabled());
                o.put("btOn", ba != null && ba.isEnabled());
                o.put("hot", hs != null);
                o.put("hsSsid", hsS);
                o.put("hsPass", hsP);
                NetworkInfo ni = ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
                o.put("net", ni == null || !ni.isConnected() ? "none" : ni.getType() == ConnectivityManager.TYPE_WIFI ? "wifi" : ni.getType() == ConnectivityManager.TYPE_MOBILE ? "cellular" : "other");
                String ss = wm.getConnectionInfo().getSSID();
                o.put("ssid", ss == null ? "" : ss.replace("\"", ""));
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }

        @JavascriptInterface public void wifi(boolean on) { wm.setWifiEnabled(on); }

        @JavascriptInterface public void bt(boolean on) {
            if (ba == null) return;
            if (on) ba.enable(); else ba.disable();
        }

        @JavascriptInterface public void scanWifi() {
            try { wm.startScan(); } catch (Exception e) {}
            pushScan();
        }

        @JavascriptInterface public void connectWifi(final String ssid, final boolean sec) {
            runOnUiThread(() -> {
                if (!sec) { join(ssid, null); return; }
                final EditText e = new EditText(MainActivity.this);
                e.setHint("Sandi Wi-Fi");
                e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                new AlertDialog.Builder(MainActivity.this).setTitle(ssid).setView(e)
                    .setPositiveButton("Sambungkan", (d, w) -> join(ssid, e.getText().toString()))
                    .setNegativeButton("Batal", null).show();
            });
        }

        @JavascriptInterface public void hotspot(final boolean on) {
            runOnUiThread(() -> {
                if (!on) {
                    if (hs != null) { hs.close(); hs = null; }
                    msg("Hotspot lokal dimatikan");
                    return;
                }
                if (hs != null) return;
                try {
                    wm.startLocalOnlyHotspot(new WifiManager.LocalOnlyHotspotCallback() {
                        @Override public void onStarted(WifiManager.LocalOnlyHotspotReservation r) {
                            hs = r;
                            WifiConfiguration c = r.getWifiConfiguration();
                            hsS = c.SSID;
                            hsP = c.preSharedKey;
                            msg("Hotspot lokal aktif: " + hsS);
                        }
                        @Override public void onStopped() { hs = null; msg("Hotspot berhenti"); }
                        @Override public void onFailed(int why) { hs = null; msg("Hotspot gagal (kode " + why + "). Pastikan Lokasi menyala."); }
                    }, ui);
                } catch (Exception e) { msg("Hotspot gagal: " + e.getMessage()); }
            });
        }

        @JavascriptInterface public void scanBt() {
            try {
                if (ba == null || !ba.isEnabled()) { msg("Bluetooth mati"); return; }
                if (ba.isDiscovering()) ba.cancelDiscovery();
                ba.startDiscovery();
            } catch (Exception e) { msg("Gagal memindai Bluetooth"); }
        }

        @JavascriptInterface public void pairBt(String a) {
            try { ba.cancelDiscovery(); ba.getRemoteDevice(a).createBond(); }
            catch (Exception e) { msg("Gagal memasangkan"); }
        }

        @JavascriptInterface public void unpairBt(final String a, final String n) {
            runOnUiThread(() -> new AlertDialog.Builder(MainActivity.this).setTitle("Lepas pasangan?").setMessage(n)
                .setPositiveButton("Lepas", (d, w) -> {
                    try { BluetoothDevice x = ba.getRemoteDevice(a); x.getClass().getMethod("removeBond").invoke(x); }
                    catch (Exception e) { msg("Gagal melepas pasangan"); }
                })
                .setNegativeButton("Batal", null).show());
        }

        @JavascriptInterface public void bonded() { pushBonded(); }

        @JavascriptInterface public void locStart() {
            runOnUiThread(() -> {
                try {
                    boolean g = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
                    boolean n = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
                    if (!g && !n) { locErr("Layanan lokasi di HP mati. Nyalakan dulu dari panel notifikasi."); return; }
                    if (g) lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, ll);
                    if (n) lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000, 0, ll);
                    Location x = lm.getLastKnownLocation(g ? LocationManager.GPS_PROVIDER : LocationManager.NETWORK_PROVIDER);
                    if (x != null) pushLoc(x);
                } catch (SecurityException e) {
                    perm();
                    locErr("Izin lokasi belum diberikan. Izinkan lalu coba lagi.");
                } catch (Exception e) { locErr("Lokasi gagal: " + e.getMessage()); }
            });
        }

        @JavascriptInterface public void locStop() {
            runOnUiThread(() -> { try { lm.removeUpdates(ll); } catch (Exception e) {} });
        }

        @JavascriptInterface public void bars(final boolean dark, final int rgb) {
            runOnUiThread(() -> {
                Window w = getWindow();
                int c = 0xFF000000 | rgb;
                w.setStatusBarColor(c);
                w.setNavigationBarColor(c);
                int fl = dark ? 0 : (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
                w.getDecorView().setSystemUiVisibility(fl);
            });
        }
    }
}
